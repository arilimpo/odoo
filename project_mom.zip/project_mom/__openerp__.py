# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Minutes of Meeting',
    'version': '1.0',
    'category': 'Project',
    'sequence': 5,
    'summary': 'Minutes of Meeting, Discussion, Policies, Follow-up',
    'description': """
Minutes of Meeting Management related Project & Calendar (Meeting)
====================================================

""",
    'website': 'http://www.artsys.id',
    'depends': [
        'project',
        'calendar',
    ],
    'data': [
        'security/ir.model.access.csv',
        'project_mom_view.xml',
        'calendar_view.xml',
        'project_view.xml',
        'project_mom_report.xml',
        'views/report_project_mom.xml',
    ],
    'demo': [
    ],
    'test': [
    ],
    'css': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
