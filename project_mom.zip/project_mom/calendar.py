from datetime import datetime, date
from lxml import etree
import time

from openerp import api
from openerp import SUPERUSER_ID
from openerp import tools
from openerp.osv import fields, osv
from openerp.tools.translate import _
from openerp.exceptions import UserError

class calendar_event(osv.osv):
    _inherit = "calendar.event"

    def _project_mom_count(self, cr, uid, ids, field_name, arg, context=None):
        Event = self.pool['project.mom']
        return {
            meeting_id: Event.search_count(cr,uid, [('calendar_id', '=', meeting_id)], context=context)
            for meeting_id in ids
        }

    _columns = {
        'partner_id': fields.many2one('res.partner', 'Client'),
        'project_id': fields.many2one('project.project', 'Project'),
        'task_id': fields.many2one('project.task', 'Task'),
        'project_mom_count': fields.function(_project_mom_count, string='Minutes of Meeting(s)', type='integer'),
    }
    _defaults = {
    }
    
calendar_event()    


    
