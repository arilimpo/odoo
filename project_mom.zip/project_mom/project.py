from openerp.osv import fields, osv

class project_task(osv.osv):
    _inherit = "project.task"
    _columns = {
        'calendar_id': fields.many2one('calendar.event', 'Meeting'),
        'mom_id': fields.many2one('project.mom', 'MOM', help="Minutes of Meeting"),
    }
    _defaults = {
    }
    
project_task()
