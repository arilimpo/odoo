from datetime import datetime, date
from lxml import etree
import time

from openerp import api
from openerp import SUPERUSER_ID
from openerp import tools
from openerp.osv import fields, osv
from openerp.tools.translate import _
from openerp.exceptions import UserError



class project_mom(osv.osv):
    _name = "project.mom"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = "Minutes of meeting of project"
    _columns = {
        'name': fields.char('MOM Name', size=128, required=True),
        
        'calendar_id': fields.many2one('calendar.event', 'Appointment Meeting'),
        'partner_id': fields.many2one('res.partner', 'Client'),
        'project_id': fields.many2one('project.project', 'Project'),
        'task_id': fields.many2one('project.task', 'Task'),
        'start': fields.datetime('Start Date'),
        'stop': fields.datetime('End Date'),
        
        'discuss_ids': fields.one2many('project.mom.discuss', 'mom_id', 'Discussion',  ondelete='cascade',),
        'policies_ids': fields.one2many('project.mom.policies', 'mom_id', 'Policy',  ondelete='cascade'),
        'fu_ids': fields.one2many('project.mom.fu', 'mom_id', 'Follow Up by Artsys',  ondelete='cascade'),
        'task_ids': fields.one2many('project.task', 'mom_id', 'Taks list', ondelete='restrict'),
    }

    def oc_calendar_event(self, cr, uid, ids, field, context=None):
        values = {}
        if field:
            obj = self.pool.get('calendar.event').browse(cr, uid, field, context=context)
            values = {
                'partner_id' : obj.partner_id.id,
                'project_id' : obj.project_id.id,
                'task_id' : obj.task_id.id,
                'start' : obj.start,
                'stop' : obj.stop,
                }
        return {'value' : values}
    
project_mom()
    
    
class project_mom_discuss(osv.osv):
    _name = "project.mom.discuss"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = "Discussion of Meeting"
    _columns = {
        'name': fields.char('Subject to Discuss', size=128, required=True),
        'note': fields.text('Subject Detail', help="Explain more detail about the subject to discuss if any"),
        'calendar_id': fields.related('mom_id', 'calendar_id', type='many2one', relation='calendar.event', string='Appointment Meeting'),
        'partner_id': fields.related('mom_id', 'partner_id', type='many2one', relation='res.partner', string='Client'),
        'project_id': fields.related('mom_id', 'project_id', type='many2one', relation='project.project', string='Project'),
        'task_id': fields.related('mom_id', 'task_id', type='many2one', relation='project.task', string='Task'),
        'start': fields.related('mom_id', 'start', type='datetime', relation='calendar.event', string='Start Date'),
        'stop': fields.related('mom_id', 'stop', type='datetime', relation='calendar.event', string='End Date'),
        'mom_id': fields.many2one('project.mom', 'Minutes Meeting'),
    }
project_mom()

class project_mom_policies(osv.osv):
    _name = "project.mom.policies"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = "Policies"
    _columns = {
        'name': fields.char('Policies', size=128, required=True),
        'note': fields.text('Policies Details', help="Explain more detail of Policies if any"),
        'calendar_id': fields.related('mom_id', 'calendar_id', type='many2one', relation='calendar.event', string='Appointment Meeting'),
        'partner_id': fields.related('mom_id', 'partner_id', type='many2one', relation='res.partner', string='Client'),
        'project_id': fields.related('mom_id', 'project_id', type='many2one', relation='project.project', string='Project'),
        'task_id': fields.related('mom_id', 'task_id', type='many2one', relation='project.task', string='Task'),
        'start': fields.related('mom_id', 'start', type='datetime', relation='calendar.event', string='Start Date'),
        'stop': fields.related('mom_id', 'stop', type='datetime', relation='calendar.event', string='End Date'),
        'mom_id': fields.many2one('project.mom', 'Minutes Meeting'),
        'state': fields.selection([('open','Open'),
                                   ('under','Under Discussion'),
                                   ('Confirm', 'Confirm'),
                                   ('cancel','Cancel')],
                                  'Status', required=True),
    }
    _defaults = {
        'state': 'open',
    }
    
project_mom()

class project_mom_fu(osv.osv):
    _name = "project.mom.fu"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = "Follow Up By Artsys"
    _columns = {
        'name': fields.char('Follow-up', size=128, required=True),
        'note': fields.text('Follow-up Details', help="Explain more detail of Follow-up if any"),
        'calendar_id': fields.related('mom_id', 'calendar_id', type='many2one', relation='calendar.event', string='Appointment Meeting'),
        'partner_id': fields.related('mom_id', 'partner_id', type='many2one', relation='res.partner', string='Client'),
        'project_id': fields.related('mom_id', 'project_id', type='many2one', relation='project.project', string='Project'),
        'task_id': fields.related('mom_id', 'task_id', type='many2one', relation='project.task', string='Task'),
        'start': fields.related('mom_id', 'start', type='datetime', relation='calendar.event', string='Start Date'),
        'stop': fields.related('mom_id', 'stop', type='datetime', relation='calendar.event', string='End Date'),
        'fuby': fields.selection([('client','Client'),('artsys','Artsys')], 'Follow-up by'),
        'mom_id': fields.many2one('project.mom', 'Minutes Meeting'),
        'state': fields.selection([('open','Open'),
                                   ('inprogress','In Progress'),
                                   ('delivered', 'Delivered / Test'),
                                   ('received','Received / Done'),
                                   ('cancel','Cancel')],      
                                  'Status'),
    }
    _defaults = {
        'state': 'open',
    }
    
project_mom()    
    
    
